def test_import():
    import boundaryscheme

    assert True
